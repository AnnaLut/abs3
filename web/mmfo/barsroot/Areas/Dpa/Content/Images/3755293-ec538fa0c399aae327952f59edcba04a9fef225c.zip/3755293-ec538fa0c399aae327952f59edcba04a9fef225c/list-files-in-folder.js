function listFilesInFolder() {
  var folder = DocsList.getFolder("Maudesley Debates");
  var contents = folder.getFiles();
  
  var file;
  var data;
  
  var sheet = SpreadsheetApp.getActiveSheet();
  sheet.clear();
  
  sheet.appendRow(["Name", "Date", "Size", "URL", "Download", "Description", "Type"]);

  for (var i = 0; i < contents.length; i++) {
    file = contents[i];
    
    if (file.getFileType() == "SPREADSHEET") {
      continue;
    }
        
    data = [ 
      file.getName(),
      file.getDateCreated(),
      file.getSize(),
      file.getUrl(),
      "https://docs.google.com/uc?export=download&confirm=no_antivirus&id=" + file.getId(),
      file.getDescription(),
      "audio/mp3"
    ];
      
    sheet.appendRow(data);
  }
};
